package com.main.dao;

import com.main.model.Customer;

public interface CustomerDao {

	public void getAllCustomerData();

	public void getCustomerDataById(int custId);

	public void SaveCustomarData(Customer customer);

	public void updateCustomerData(int custId, String custName, long custContactNumber);

	public void deleteCustomerDataById(int custId);

	public void deleteAllCustomerData();
}