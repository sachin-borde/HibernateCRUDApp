package com.main.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.main.model.Customer;

public class CustomerDaoImpl implements CustomerDao {

	private static SessionFactory factory = new AnnotationConfiguration().configure().buildSessionFactory();

	@Override
	public void getAllCustomerData() {
		Session session = factory.openSession();
		List<Customer> customers = session.createQuery("from Customer").list();
		customers.forEach(System.out::println);
	}

	@Override
	public void getCustomerDataById(int custId) {
		Session session = factory.openSession();
		List<Customer> customers = session.createQuery("from Customer").list();
		for (Customer c : customers) {
			if (c.getCustId() == custId) {
				System.out.println(c);
			}
		}
	}

	@Override
	public void SaveCustomarData(Customer customer) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(customer);
		transaction.commit();
	}

	@Override
	public void updateCustomerData(int custId, String custName, long custContactNumber) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		List<Customer> customers = session.createQuery("from Customer").list();
		for (Customer c : customers) {
			if (c.getCustId() == custId) {
				c.setCustName(custName);
				c.setCustContactNumber(custContactNumber);
				session.update(c);
				transaction.commit();
			}
		}
	}

	@Override
	public void deleteCustomerDataById(int custId) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		List<Customer> customers = session.createQuery("from Customer").list();
		for (Customer c : customers) {
			if (c.getCustId() == custId) {
				session.delete(c);
				transaction.commit();
			}
		}
	}

	@Override
	public void deleteAllCustomerData() {
		Session session = factory.openSession();
		List<Customer> customers = session.createQuery("from Customer").list();
		for (Customer c : customers) {
			Transaction transaction = session.beginTransaction();
			session.delete(c);
			transaction.commit();
		}
	}
}
