package com.main.service;

import com.main.dao.CustomerDao;
import com.main.dao.CustomerDaoImpl;
import com.main.model.Customer;

public class CustomerService {
	public static void main(String[] args) {

		CustomerDao customerDaoImpl = new CustomerDaoImpl();

		Customer customer = new Customer();
		customer.setCustName("nikhil");
		customer.setCustContactNumber(1234567890);

		//customerDaoImpl.SaveCustomarData(customer);
		//customerDaoImpl.getCustomerDataById(3);
		//customerDaoImpl.updateCustomerData(2, "SACHIN", 63466765765L);
		//customerDaoImpl.deleteCustomerDataById(1);
		//customerDaoImpl.deleteAllCustomerData();
		//customerDaoImpl.getAllCustomerData();
	}
}
